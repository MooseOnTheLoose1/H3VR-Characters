[Relaxed Reuben](https://imgur.com/a/iT5myw4)

### Have a nice relaxing hold.

This character was created intending to provide a nice relaxing Take and Hold experience, full of overpowered guns, too many tokens to hold, and lots and lots of easy to kill sosig cannonfodder. Recommended to play on no targets and endless, with the health option of your choice!

### Requirements:
- [TNH Tweaker](https://github.com/devyndamonster/TakeAndHoldTweaker)

### Installation
Install with the mod manager of your choice.

### Supported Mods
- [Meats ModulAR](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAR/)
- [Meats ModulSIG](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulSIG/)
- [Meats ModulAK](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAK/)
- [Meats ModulShotguns](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulShotguns/)
- [Meat and Melons MVP](https://h3vr.thunderstore.io/package/Meat_banono/Meat_and_Melons_MVP/)
- [Meats ASH12](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ASh12/)
- [Jayyden's Modern Warfighter Lasers and Lights](https://h3vr.thunderstore.io/package/jayyden/ModernWarfighterLaserAndLights/)
- [Jayyden's Modern Warfighter Optics](https://h3vr.thunderstore.io/package/jayyden/ModernWarfighterOptics/)
- [Andrew_FTW's MK18 Mjolnir](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Mk18_Mjolnir/)
- [Andrew_FTW's Foregrips](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Foregrips/)
- [Andrew_FTW's Tactical Backpacks](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Tactical_Backpack/)
- [Andrew_FTW's M26 MASS](https://h3vr.thunderstore.io/package/Andrew_FTW__CityRobo/FTW_Arms_M26_MASS/)
- [Andrew_FTW and Meats Modul870Magfed](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_and_Meat_Bananas_Modular_870_Magfed/) 
- [Nayr31's Muzzsil](https://h3vr.thunderstore.io/package/nayr31/MuzzSil/)
- [Shampooh's FNX .45 Tactical](https://h3vr.thunderstore.io/package/Shampooh/FNX_45_Tactical/)
- [Shampooh's Optics](https://h3vr.thunderstore.io/package/Shampooh/Shampoohs_Optics/)
- [Jayyden's Glock 19 Custom Series](https://h3vr.thunderstore.io/package/jayyden/Glock19CustomSeries/)
- [Jayyden's P226 Series](https://h3vr.thunderstore.io/package/jayyden/SigSauerP226Series/)
- [Muzzle's Kimber Super Jagare](https://h3vr.thunderstore.io/package/Muzzle/Kimber_Super_Jagare/)
- [Muzzle's Beowulf AR15](https://h3vr.thunderstore.io/package/Muzzle/50_Beowulf_AR15/)
- [Muzzle's Wilson Combat 1911](https://h3vr.thunderstore.io/package/Muzzle/Wilson_Combat_1911_Commander/)
- [Muzzle's Coonan Compact Magnum](https://h3vr.thunderstore.io/package/Muzzle/Coonan_Compact_Magnum/)
- [Arpy's Taran Tactical 2011](https://h3vr.thunderstore.io/package/Arpy/Taran_Tactical_2011/)
- And potentially even more that I forgot about!

### Changelog
- 1.0.4 Updated weapon progression and enemy types to make character even more relaxed, also added custom Modul guns to loot pools.
- 1.0.3 Fixed equipment pools so more variation of pistols will spawn from constructors.
- 1.0.2 Actually Fixed versioning issue causing character to not appear in TNH lobby.
- 1.0.1 Thought I Fixed versioning issue causing character to not appear in TNH lobby.
- 1.0.0 Initial Upload.