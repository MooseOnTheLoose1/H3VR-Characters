Looting Larry - Moose Edit

Enjoy classic Looting Larry gameplay with compatibility for all your favorite mods!  (Focused mostly on modern western weaponry, such as ModulAR,SIG,HK416,Kilo141,M1A, etc etc.)
Enemies drop guns, but you have to buy your mags
Lots of enemies
Short holds

Moose's updates

Basically what I did here was change all the loot pools to include a bunch of new mods, added a few of my own custom vault file Modul Gun builds to add some variety to the basic AR drops, added A ModulAR parts group for constructor panels so you can buy parts directly, and updated some Id's to make stuff spawn properly :)

Added Guns/Items from the following mods;
MP443_Grach by Not_Wolfie
Meats_M45A1 by Meat_banono
Modul_USP by Not_Wolfie
The_Glock_Pack by Muzzle_Alt
FTW_Arms_Mk18_Mjolnir by Andrew_FTW
Glock19CustomSeries by jayyden
MuzzSil by nayr31
Modul_FAL by Not_Wolfie
FTW_Arms_Foregrips by Andrew_FTW
FTW_Arms_Modern_Warfighter_Remastered by Andrew_FTW
modulSVD by nayr31
Modul_M700 by Not_Wolfie
Taran_Tactical_2011 by Arpy
MP7A1_And_MP7A2 by Not_Wolfie
Modul_HK by Not_Wolfie
FTW_Arms_P50 by Andrew_FTW
FTW_Arms_M26_MASS by Andrew_FTW__CityRobo
FTW_Arms_Modular_M1a by Andrew_FTW
SIG_P320 by Muzzle
ModularHK417_and_NightVision by sgtbrooks
And probably a few more I forgot, Play it and find out!

Update 1.1.0:
Initial Release - Updated ReadME with proper changes, balancing pass, added more items to constructor pools. 

Update 1.0.0:
Initial Release - Will likely have bugs, ping me on discord if you find something.