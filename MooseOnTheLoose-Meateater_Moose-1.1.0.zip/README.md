[Meateater Moose](https://imgur.com/a/azHV440)

### Blast away sosigs with high end weaponry!

This character was created to give a TnH experience that works seamlessly with Meats ModulAR and ModulAK mods, spawning them for your primary weapon, as well as most of the weapons from there on.This character also includes custom Modul parts constructor categories, thanks to Devyndamonster and his gracious permission to use PMC Petes resources! High octane, full auto firefights await! Moose spawns with an assault rifle, a hi-cap automatic handgun, a knife, a health powerup, and a reflex sight. This character is intended to be played with at least the 2 main MODUL mods installed, and ideally the entire list of supported mods, so get installing, and enjoy a absolutley BALLISTIC Take and Hold experience!

### Requirements:
- [TNH Tweaker](https://github.com/devyndamonster/TakeAndHoldTweaker)

### Installation
Install with the mod manager of your choice.

### Necessary Mods - !This Character was developed to be played with AT LEAST these following mods!
- [Meats ModulAR](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAR/)
- [Meats ModulAK](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAK/)
- [Andrew_FTW's Modern Warfighter Remastered](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modern_Warfighter_Remastered/)
- [Andrew_FTW's Modular M1a](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modular_M1a/)
- [Andrew_FTW's Modular Vector](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modular_Vector/)
- [Not_Wolfie's Modul M700](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_M700/)
- [Not_Wolfie's Modul HK](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_HK/)

### Highly Recommended Mods - !This Character was developed wihth these mods, and I feel they greatly enhance the experience!
- [Shampooh's Optics](https://h3vr.thunderstore.io/package/Shampooh/Shampoohs_Optics/)
- [Shampooh's FNX .45 Tactical](https://h3vr.thunderstore.io/package/Shampooh/FNX_45_Tactical/)
- [Jayyden's Glock 19 Custom Series](https://h3vr.thunderstore.io/package/jayyden/Glock19CustomSeries/)
- [Meats ModulSIG](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulSIG/)
- [Meats ModulShotguns](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulShotguns/)
- [Andrew_FTW's MK18 Mjolnir](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Mk18_Mjolnir/)
- [Andrew_FTW's Foregrips](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Foregrips/)
- [Andrew_FTW's Edged Weapons Pack](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Edged_Weapons_Pack/)
- [Nayr31's Muzzsil](https://h3vr.thunderstore.io/package/nayr31/MuzzSil/)
- [Muzzle's Beowulf AR15](https://h3vr.thunderstore.io/package/Muzzle/50_Beowulf_AR15/)
- [Jayyden's P226 Series](https://h3vr.thunderstore.io/package/jayyden/SigSauerP226Series/)
- [Not_Wolfie's Modul Kilo141](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_Kilo141/)
- [Not_Wolfie's Modul FAL](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_FAL/)

### Supported Mods - Also recommended, but additional only, not necessary for the general experience of the character.
- [Meat and Melons MVP](https://h3vr.thunderstore.io/package/Meat_banono/Meat_and_Melons_MVP/)
- [Andrew_FTW's M26 MASS](https://h3vr.thunderstore.io/package/Andrew_FTW__CityRobo/FTW_Arms_M26_MASS/)
- [Andrew_FTW's DSR-50](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_DSR50/)
- [Andrew_FTW's AR-50](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_AR50/)
- [Andrew_FTW's KelTec P50](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_P50/)
- [Muzzle's Kimber Super Jagare](https://h3vr.thunderstore.io/package/Muzzle/Kimber_Super_Jagare/)
- [Muzzle's Wilson Combat 1911](https://h3vr.thunderstore.io/package/Muzzle/Wilson_Combat_1911_Commander/)
- [Muzzle's Coonan Compact Magnum](https://h3vr.thunderstore.io/package/Muzzle/Coonan_Compact_Magnum/)
- [Arpy's Taran Tactical 2011](https://h3vr.thunderstore.io/package/Arpy/Taran_Tactical_2011/)

### Changelog
- 1.1.0 Updated constructor pools with custom made ModulGuns, and with overall better variety, including more long range guns for bigger maps.
- 1.0.0 Initial Upload.